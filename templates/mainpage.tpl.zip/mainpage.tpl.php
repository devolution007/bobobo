﻿<?
if ( !defined('INCLUDED') ) { die("Access Denied"); }
?><br />
 
 <br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br /> <div class="window">
  <div class="logo">
    <p class="top">Microsoft</p>
    <p class="mid">Windows<span>XP</span></p>
    <p class="bottom">Professional</p>
  </div>
  <div class="container1">
    <div class="box"></div>
    <div class="box"></div>
    <div class="box"></div>
  </div>
</div>


<style type="text/css">
<!--
.style2 {color: #000000}
-->
</style>
<br />
 
<style type="text/css">
<!--
.text-white a {
 
	color: #FFFFFF;
}

.text-white  {
 
	color: #FFFFFF;
}
 .today {
background: url(themes/<?=$setts['default_theme'];?>/news.png) top right no-repeat;
}
.day {
background: #ffffff url(themes/<?=$setts['default_theme'];?>/img/day.gif) bottom left no-repeat;
}






@import url('https://fonts.googleapis.com/css?family=Roboto:100,300,700');
body1{
  background: #000; 
  font-family: 'Roboto', sans-serif; 
  color: #fff;
}
.window{
  position: absolute;
   
    left: 50%;
    margin-right: -50%;
    transform: translate(-50%, -50%)
 
}
.container1{
  width: 150px;
  height: 10px;
  border: 2px solid #b2b2b2;
  border-radius: 7px;
  margin: 0 auto;
  padding: 2px 1px;
  overflow: hidden;
  font-size: 0;
}
.box{
  width: 9px;
  height: 100%;
  background: linear-gradient(to bottom, #2838c7 0%,#5979ef 17%,#869ef3 32%,#869ef3 45%,#5979ef 59%,#2838c7 100%);
  display: inline-block;
  margin-right: 2px;
  animation: loader 2s infinite;
  animation-timing-function: linear;
}
.logo{
  width: 220px;
  margin: 50px auto;
}
.logo p{
  margin: 0;
  padding: 0;  
}
.top{
  font-size: 16px;
  font-weight: 300;
  line-height: 16px;
}
.top:after{
  content:"\00a9";
  font-size: 10px;
  position: relative;
  top: -5px;
  margin-left: 2px;
}
.mid{
  font-size: 46px;
  font-weight: 700;
  line-height: 36px;  
}
.mid span{
  font-size: 22px;
  display: inline-block;
  vertical-align: top;
  color: #FF6821;
  margin-top: -8px;
}
.logo .bottom{
  font-size: 30px;
  font-weight: 300;
  line-height: 30px;
  margin-left: 5px;
  
}
@keyframes loader{
  0%{
    transform: translate(-30px);
  }
  100%{
    transform: translate(150px);
  }
}









-->
</style>


 
<? if ($member_active == 'Active') { ?> <?=$menu_box_content;?><? } else { ?> <br />   

<div class="d-lg-none"><br />

 
<ul id="countrytabs" class="shadetabs nav justify-content-center">
<li><a  href="#" rel="#default" class="selected">NSQ.RU</a></li>
<li><a  href="soft1.php" rel="countrycontainer ">SOFT</a></li>

<li><a  href="hard1.php" rel="countrycontainer ">ЖЕЛЕЗО</a></li>
<li><a href="1.php" rel="countrycontainer">ВХОД</a></li>

</ul>
<br />


<div id="countrydivcontainer" style="border:0px solid gray; width:100%; margin-bottom: 1em; padding: 5px">
<p>Repair saves you money. It saves the environment. And it connects us to our things.!<br />
Самостоятельный легкий ремонт сбережет ваши деньги. Перед ремонтом  обязательно сохраняйте <a href="http://nbw.ru/Zagruzka-sistem,category,759,parent_id,wanted_ads">информацию с устройства</a>
<hr class="my-4"> 
<p>Если ваш компьютер или ноутбук:</p>
<ul>
  <li>не включается;</li>
  <li>не загружается;</li>
  <li>периодически выключается без команды или перезагружается;</li>
  <li>сильно шумит и греется;</li>
  <li>работает очень медленно, выдает непонятные сообщения, теряет данные -</li>
</ul><hr class="my-4"> 
Проблемы внешние, эксплуатационные   – сбои питания в сети,   повреждения устройства, попадание жидкостей, загрязнения системы   охлаждения, с компьютерами, ноутбуками, планшетами и методы их решения. см ссылки каталога
</div>
<header>
      <div class="collapse bg-dark" id="navbarHeader">
        <div class="container">
          <div class="row">
            <div class="col-sm-8 col-md-7 py-4">
              <h4 class="text-white ">Рекомендуем самим </h4>
              <p class="text-white"> <cite title="Source Title"><ol>
  <li  class="text-white" >-Проводить предварительную диагностику компьютера или ноутбука.</li>
  <li class="text-white" >-При обнаружении неполадок выяснять, где может находиться источник проблем, сбоев неисправностей.</li>
  <li  class="text-white">-Используя специальное программное обеспечение, проверять работу   системы или внутренних узлов, находит причину неправильной работы   техники.</li>
  <li  class="text-white">-Пути устранения проблемы, озвучивая размеры затрат на ремонт или восстановление.</li>
  <li  class="text-white">-Устранить самому неисправность.</li>
  <li  class="text-white" >-Проверить устройство на работоспособность </li>
</ol></cite><br />
Если не смогли сами то звоните по указанным на сайте телефонам </p>
            </div>
            <div class="col-sm-4 offset-md-1 py-4">
              <h4 class="text-white"><i class="fas fa-map-marked-alt"></i>
NSQ RU</h4>
              
			  
			  
			  
			  
			  
			
   
  <address class="text-white">
 
    191024 СПб, Россия<br>
    Невский пр, 134  16Н<br>
    <abbr title="Phone"><i class="fa fa-phone" aria-hidden="true"></i>
:</abbr> (812) 694-9092<br>
  <abbr title="Phone"><i class="fa fa-phone" aria-hidden="true"></i>
:</abbr> +7 (996) 78-45-747
</address>
 <address> 
<strong>
  <h5> <a href="https://twitter.com/wwwnsqru"> <i class="icon-twitter-sign"></i> </i> 
</a></h5></strong>
  </address>
</div>
</div>
</div>
</div>
<div class="navbar navbar-dark bg-dark box-shadow">
 <div class="container d-flex justify-content-between">
          <a href="#" class="navbar-brand d-flex align-items-center">
        <i class="fas fa-map-marked-alt"></i>
            <strong>&nbsp; Невский 134 - 16Н</strong>
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
          </button>
      </div>
    </div>
  </header>
<br />

</div>


<br />






  <div class="d-none d-lg-block"> 
  
 
  
  
  
  
  
  
  
  
  
  
  
  
  
  

  <h1 class="display-4">SOFT!</h1>
  



  
  
  
  
  
  
  
  
  
  
  
  <div class="collapse" id="navbarHeader1">
        <div class="container">
<table width="99%" class="table table-sm">
  

       <?=$subcategories_content;?>
    
</table>
</div></div>
  
  <div class="navbar navbar-dark bg-dark box-shadow">
 <div class="container d-flex justify-content-between">
        
          <button class=" navbar-toggler text-white" type="button" data-toggle="collapse" data-target="#navbarHeader1" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation"> <i class="fas fa-arrow-alt-circle-down"></i> <i class="icon-android"></i> <i class="icon-apple"></i>  <i class="icon-windows"></i>  <i class="icon-linux"></i>   ссылки каталога SOFT  
<span class="navbar-toggler-icon"></span>
          </button>
      </div></div>
  <hr class="my-4">
<div class="row">
    <div class="col-sm-6">  
	
	<blockquote class="blockquote">
<p class="lead style2">Неполадки, неисправности и сбои компьютера  </p> 
  <footer class="blockquote-footer"> <cite title="Source Title">Мы публикуем ссылки наиболее актуальные и проблемные темы по обслуживанию и ремонту компьютерной техники. Только выдержанные ссылки для последующей помощи пользователям компьютеров и прочей техники под управлением ОС. Source  Win Android или Linux. Mac OS Apple.. Изменяя настройки системы, запоминайте свои последние действия и   сохраняйте информацию в резервных копиях.</cite></footer></blockquote>
	 <footer class="blockquote-footer"> <cite title="Source Title">Сайт создан   с ознакомительной тематикой и не дает четких инструкций и указаний по ремонту техники. Все зависит от пройденного материала и умения. Перед ремонтом обязательно сохраняйте данные с устройства  NSQ.RU  ! </cite></footer> 
	</div> 
	
	
	
	
	
	
	
	
	
	
	

    <div class="col-sm-6">
	
	 <ul class="list-group">  <a class="list-group-item  list-group  bg-dark text-white" href="index_users.php"><i class="icon-sitemap"></i>  &nbsp; <i class="icon-cog "></i> NSQ  <?=$current_date;?> </a>
 
 
 
<li class="list-group-item d-flex justify-content-between align-items-center">
  <a href="<?=process_link('reverse_auctions');?>">   Железо </a> 
           
    <span class="badge badge-primary badge-pill"> <i class="icon-upload"></i>&nbsp; <?=$nb_live_reverse_auctions;?></span>
  </li>


  <li class="list-group-item d-flex justify-content-between align-items-center">
  <a href="<?=process_link('wanted_ads');?>"> Софт Настройки</a> 
    <span class="badge badge-primary badge-pill"> <i class="icon-cogs"></i>&nbsp; <?=$nb_live_wanted_ads;?></span>
  </li>
  
    <li class="list-group-item d-flex justify-content-between align-items-center">
  <a href="faq,page,content_pages"> Wifi и роутеры настройки</a> 
    <span class="badge badge-primary badge-pill"> <i class="icon-cogs"></i>&nbsp;Wifi GSM Сеть</span>
  </li>
  
  
  
  
  
  
  <li class="list-group-item d-flex justify-content-between align-items-center">
    <a href="index_users.php">Пользователи</a>    <span class="badge badge-primary badge-pill">&nbsp;  <?=$nb_site_users;?></span>  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center">
Сейчас
    <span class="badge badge-primary badge-pill"> <i class="icon-upload"></i>&nbsp;<?=$nb_online_users;?></span>
  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center">
 <a href="register.php">Регистрация на сайте </a> 
    <span class="badge badge-primary badge-pill"> &nbsp;+&nbsp;<i class="icon-group"></i>&nbsp; </span>
  </li>
  
  
</ul>
	
 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	</div></div>


 
   
  <hr class="my-4">
<blockquote class="blockquote">
  <p class="mb-0">С чего начать знакомство с   операционной системой и как её настроить под себя..</p>
  <footer class="blockquote-footer"> <cite title="Source Title">  <i class="icon-android"></i> <i class="icon-apple"></i>  <i class="icon-windows"></i>  <i class="icon-linux"></i>   Win Android или Linux. Mac OS Apple откройте ссылку на каталог и выберите систему с которой работаете . </cite></footer>
</blockquote>

  <hr class="my-4">
  


 
 
 


 
    <hr class="my-4">
<div class="collapse" id="navbarHeader2"><div class="container">
 <?
$content = file_get_contents("http://nbw.ru/index_hard.php");
$pos = strpos($content, "<!-- rev -->");
$content = substr($content, $pos); 
$pos = strpos($content, "<!-- rev2 -->"); 
$content = substr($content, 0, $pos); 
echo $content;
?></div></div>

<div class="navbar navbar-dark bg-dark box-shadow">
 <div class="container d-flex justify-content-between">
        
          <button class=" navbar-toggler text-white" type="button" data-toggle="collapse" data-target="#navbarHeader2" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation"> <i class="fas fa-arrow-alt-circle-down"></i>  <i class="fas fa-desktop"></i>&nbsp;<i class="fas fa-plug"></i> &nbsp;<i class="fas fa-memory"></i>&nbsp;<i class="fas fa-keyboard"></i>&nbsp;<i class="fas fa-sd-card"></i> ссылки каталога ЖЕЛЕЗО  
<span class="navbar-toggler-icon"></span>
          </button>
      </div></div> 
  
  
  
  
  
    <hr class="my-5">
  
  
  
  

 <div class="row"> <div class="col-sm-6">

<? if ($setts['enable_wanted_ads'] && $layout['nb_want_ads']) { ?>
 <? 
		   $columns = 3;
		   $nb_wanted = $db->num_rows($sql_select_recent_wa);
		   
			for($i = 0; $i < $nb_wanted; $i++) 
			{
				$item_details = mysql_fetch_array($sql_select_recent_wa);
				$main_image = $db->get_sql_field("SELECT media_url FROM " . DB_PREFIX . "auction_media WHERE wanted_ad_id='" . $item_details['wanted_ad_id'] . "' AND media_type=1 AND upload_in_progress=0 ORDER BY media_id ASC LIMIT 0,1", 'media_url');
				
				if($i % $columns == 0) { ?>  <div class="row">
 <? } ?>  <div class="col-sm-12">	
 <div class="card  bg-secondary mb-2 " style="max-width: 100%;">
 <div class="card-header  bg-dark text-white   <?	if(CURRENT_TIME - $item_details['start_time'] <= 86400) { echo "today"; } ?>"><i class="fas fa-database"></i>&nbsp;<?=$item_details['state'];?>    </div>
 <div class="card-body  text-white ">  

 <p class="card-text  text-white" > <cite title="Source Title"><a class="text-white" text-white  href="<?=process_link('wanted_details', array('name' => $item_details['name'], 'wanted_ad_id' => $item_details['wanted_ad_id']));?>"><img class="round2  corners4"  align="right"  hspace="1" vspace="1"     src="<? echo ((!empty($main_image)) ? 'thumbnail.php?pic=' . $main_image . '&w=350&sq=Y' : 'themes/' . $setts['default_theme'] . '/noimg.svg');?>" border="0" height="200" alt="<?=title_resize($item_details['name']);?>"></a> <a   href="<?=process_link('wanted_details', array('name' => $item_details['name'], 'wanted_ad_id' => $item_details['wanted_ad_id']));?>"><i class="fas fa-bug"></i>&nbsp;<?=$item_details['country'];?>  <br />

<i class="fas fa-registered "></i>&nbsp;<?=$item_details['addl_category_id'];?>  <footer class="blockquote-footer ">
 <cite title="Source Title"> <?=$item_details['name'];?></cite> <h6 class="card-title  text-white"><i class="fas fa-clock"></i> <?=show_date($item_details['start_time']);?></h6> </footer></a></cite>   <?=item_pics1($item_details);?>
</p>
 </div></div>
 </div>
 <? if(($i % $columns) == ($columns - 1) || ($i + 1) == $nb_wanted) { ?>
  </div>
 <? } ?>
  <? } ?>
 <? } ?>
 </div>


 <div class="col-sm-6">    <a class="list-group-item list-group  bg-dark text-white" href="wanted_ads.php">      <i class="fab fa-windows"></i> 
	  
	&nbsp;<i class="fab fa-android"></i> &nbsp; <i class="fab fa-linux"></i>&nbsp; <i class="fab fa-apple"></i>&nbsp;
 

Топ просмотры SOFT   
	  
	 </a>
  <?
include_once ('includes/global.php');
$howmany =6;
echo " <ul  class='list-group'> ";
				
 



$newuserquery = "SELECT name, nb_clicks, wanted_ad_id from probid_wanted_ads order by nb_clicks desc limit 0, $howmany";
$result = mysql_query($newuserquery) or die(mysql_error());
while($row=mysql_fetch_row($result)) {
$newusername = $row[0];
$newusercity = $row[1];
$newuserauctionid = $row[2];
$newuserlink = $path . "$newusername,name, ". $newuserauctionid .",wanted_ad_id,wanted_details";

echo " <li class='list-group-item d-flex justify-content-between align-items-center'><a href=' " . $newuserlink . " '>" . $newusername . " </a>";
 echo "  <span class='lbadge badge-primary badge-pill'>" . $newusercity . "</span>   ";
echo "</li>";
}
echo " </ul >";
?></div>


  
 <hr class="my-4">



 
</div>

  <hr class="my-5">

 

 





  <h1 class="display-4">HARD!</h1><hr class="my-2"> 
  <p class="lead">  по железу.  Сейчас на сайте . <?=$nb_live_reverse_auctions;?> вариантов.
</p> 
 <hr class="my-4">
 <div class="row">
    <div class="col-sm-6">


 <a class="list-group-item   list-group  bg-dark text-white " href="index_users.php">   <i class="fas fa-desktop"></i>&nbsp;<i class="fas fa-plug"></i> &nbsp;<i class="fas fa-memory"></i>&nbsp;<i class="fas fa-keyboard"></i>&nbsp;<i class="fas fa-sd-card"></i>
 

  Топ запросы по железу    HARD  </a>
     
  <?
include_once ('includes/global.php');
$howmany = 6;
echo " <ul  class='list-group'> ";
				
 



$newuserquery = "SELECT name, nb_clicks, reverse_id from probid_reverse_auctions order by nb_clicks desc limit 0, $howmany";
$result = mysql_query($newuserquery) or die(mysql_error());
while($row=mysql_fetch_row($result)) {
$newusername = $row[0];
$newusercity = $row[1];
$newuserauctionid = $row[2];
$newuserlink = $path . "$newusername,name, ". $newuserauctionid .",reverse_id,reverse_details";

echo " <li class='list-group-item d-flex justify-content-between align-items-center'><a href=' " . $newuserlink . " '>" . $newusername . " </a>";
 echo "  <span class='lbadge badge-dark badge-pill'>" . $newusercity . "</span>   ";
echo "</li>";
}
echo " </ul >";
?>
  
  
 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	 </div> <div class="col-sm-6">   <? if ($setts['enable_reverse_auctions'] && $layout['r_recent_nb']) { ?>   <div class="row"> <?=$browse_reverse_content;?>  </div>      
               <div align="right" style="padding: 5px;" class="conte"><a href="<?=process_link('reverse_auctions');?>">
              Разное из  мира ИТ  </a> </div>   

                <? if ($nb_items>0) { ?>
              
                <? } ?> <? } ?> </div></div>

   <hr class="my-4">
<blockquote class="blockquote">
  <p class="mb-0"> Любой  тип вашего оборудования- ноутбук, системный блок или что-то другое. </p>
  <footer class="blockquote-footer"> <cite title="Source Title">Проблемы внешние, эксплуатационные   – сбои питания в сети,   повреждения устройства, попадание жидкостей, загрязнения системы   охлаждения, с компьютерами, ноутбуками, планшетами и методы их решения. см ссылки каталога . </cite></footer>
</blockquote>



 




 
    <hr class="my-4">

 
  
  
   <h1 class="display-4">DATA !</h1>
  <p class="lead">
Хранение данных, операционные системы и серверы</p>
  <div align="center"><img  class="img-fluid" src="themes/<?=$setts['default_theme'];?>/oracl.png">
  </div>
  
  <hr class="my-4">
  <blockquote class="blockquote">
  <p class="mb-0">Содержание:   Сервер под линукс - что это зачем он нужен...С чего начать  .</p>
  <footer class="blockquote-footer"> <cite title="Source Title">   <i class="icon-linux"></i> 
80% всех интернет магазинов и устройств хранящих наши данные работают по управлением операционной системы Линукс. Хотите свой магазин в онлайн - тогда надо представление иметь что такое ИТ магазин под сервером Линукс и что он умеет .   Можно ли самому сделать магазин ОН лайн а не арендовать? Что такое виртуальная машина и зачем она. Простым языком можно все рассказать на нашем сайте. Как это работает и что хранит.  </cite></footer>
</blockquote>


  
  <hr class="my-4">
   <div class="row">
    <div class="col-sm-6  ">
<img  class="img-fluid" src="themes/<?=$setts['default_theme'];?>/ww77.png">
    </div>
    <div class="col-sm-6  ">
  <a class="list-group-item  list-group  bg-dark text-white" href="wanted_ads.php"><i class="icon-tag"></i>  &nbsp; Настройка систем    <?=$current_date;?> </a> 
  <?
$content = file_get_contents("http://nbw.ru/Zagruzka-sistem,category,759,parent_id,wanted_ads");
$pos = strpos($content, "<!-- w2 -->");
$content = substr($content, $pos); 
$pos = strpos($content, "<!-- w3 -->"); 
$content = substr($content, 0, $pos); 
echo $content;
?>
  
  
  
  
  
  
  

  
    </div>
  </div> 
 
<hr class="my-5"> 
 <div class="row">
    <div class="col-sm-3">
      <h1>  
	  
	 <i class="fab fa-android"></i> </h1>
      <p>Список обслуживаемого оборудования:</p>
      <p>  Тематика Андроид а также ссылки на актуальные приложения , сервисы и апгрей с настройками разных ОС Андроид</p>
    </div>
    <div class="col-sm-3">
      <h1><i class="fab fa-windows"></i></h1>
      <p>    Windows 10
    Windows 7
    Windows 8
    Windows XP
    DLL ошибки
    Выбираем программу
    Обзоры программ
    </p>
      <p> Работа с форматами файлов Win.</p>
    </div>
    <div class="col-sm-3">
      <h1> <i class="fab fa-apple"></i></h1>        
      <p>Установка, восстановление , апгрейд, варианты систем и приложения для Мак ОС. Старые и новые ОС </p>
      <p> Тематика Apple OS  .</p>
    </div>
	  <div class="col-sm-3">
      <h1>  <i class="fab fa-linux"></i>  </h1>        
     <p>Сервер под линукс - что это  зачем он нужен...</p>
      <p>системы Линукс. Что и зачем. Просто о сложном. Каждому реально обучиться. Как настроить Линукс  и что он умеет  . </p>
    </div>
	
	
</div>

 
Каждый день новые паблики о софтверном на нашем сайте в разделе SOFT ( 3 новых на главной странице)  






 
  

  
  
  
  
  
  
  
  
  
  
  
  
  
    <hr class="my-5">
  
  
  
  
  
  <br />

<h1 class="display-4">INFO!</h1>
  <p class="lead">
Восстановление удаленных данных ...</p>

   
  <div class="row">
    <div class="col-sm-6">   <img  class="img-fluid" src="themes/<?=$setts['default_theme'];?>/ww44.png">  </div>
   <div class="col-sm-6">    <a class="list-group-item  list-group  bg-dark text-white" href="wanted_ads.php"><i class="icon-tag"></i>  &nbsp; Восстановление информации файлов   <?=$current_date;?> </a>   
 <?
$content = file_get_contents("http://nbw.ru/Vosstanovlenie-udalennykh-dannykh,category,757,parent_id,wanted_ads");
$pos = strpos($content, "<!-- w2 -->");
$content = substr($content, $pos); 
$pos = strpos($content, "<!-- w3 -->"); 
$content = substr($content, 0, $pos); 
echo $content;
?>
    </div></div>

   
   
   
   
   
   
   
   
   
   
   
   
  
  <hr class="my-4">

  
  <hr class="my-4">

  <div class="row justify-content ">
    <div class="col-sm-4"><div class="alert alert-dark" role="alert">	
       <h2 align="center">  <i class="material-icons" style="font-size:50px;color:black;">developer_mode live_help comment feedback</i></h2> 



      <p>Всегда ли можно вернуть..</p>
      <p>Содержание:     после очистки Корзины,
    безвозвратно стертые с жесткого диска,
    после форматирования. Случайное удаление файлов, очистка «Корзины» Windows,   удаление или создание новых разделов, вирусная атака?
</p><div class="p-2 mb-2 bg-dark text-white"> <a href="http://nbw.ru/wanted_ads.php?parent_id=757&amp;name=Vosstanovlenie-udalennykh-dannykh">! можно вернуть</a> </div></div>
    </div>
    <div class="col-sm-4"><div class="alert alert-dark" role="alert">	


	
	
      <h2 align="center"><i class="material-icons" style="font-size:50px;color:black;">usb sd_storage devices_other laptop_windows</i> </h2>
	  
  <p>Восстановление удаленных данных ...</p>
      <p> 
с карт памяти SD, MicroSD, Compact Flash, внешних и встроенных жестких дисков компьютеров, ноутбуков и USB-флеш-дисков.
 восстановления данных, утерянных после форматирования, удаления или пересоздания   разделов.</p>
      <div class="p-2 mb-2 bg-dark text-white">  <a href="http://nbw.ru/Sluchajjno-ster-ili-otformatiroval,category,767,parent_id,wanted_ads">Восстановление</a>  </div></div>
    </div>
    <div class="col-sm-4"><div class="alert alert-dark" role="alert">	
      <h2 align="center" ><i class="material-icons" style="font-size:50px;color:black;">local_movies camera_alt library_music event_note </i></h2>        
      <p>Реанимация  удаленных  ...</p>
      <p> Аудио Видео Документы с 
    Microsoft Windows: ExFAT, FAT/FAT32, NTFS.
    Apple Mac OS: HFS, HFS+, APFS.
    Linux: Ext2, Ext3, Ext4, ReiserFS, JFS, XFS, Btrfs.
    Unix, BSD, Sun Solaris: UFS/UFS2, Adaptec UFS, Open ZFS, Sun ZFS.
    Novell Netware: NWFS, NSS.</p> 
	<div class="p-2 mb-2 bg-dark text-white"> <a href="http://nbw.ru/Reanimaciya-foto-i-video,category,766,parent_id,wanted_ads">Реанимация </a> </div></div>
	
	
  
    </div>
  </div>
 
<br /> 

 

  
  
  
  
  
<hr class="my-4">




 

  <h1 class="display-4">SERVICE!</h1>
  <p class="lead">
Система охлаждения компьютера.</p>
     <div class="row justify-content ">
    <div class="col-sm-6"> <img   class="img-fluid" src="themes/<?=$setts['default_theme'];?>/ww8.png"></div>
    <div class="col-sm-6">  <a class="list-group-item  list-group  bg-dark text-white" href="reverse_auctions.php"><i class="icon-tag"></i>  &nbsp; Радиаторы Кулеры и пр..    <?=$current_date;?> </a>  <?
$content = file_get_contents("http://nbw.ru/Okhlazhdenie,category,500,parent_id,reverse_auctions");
$pos = strpos($content, "<!-- rev3 -->");
$content = substr($content, $pos); 
$pos = strpos($content, "<!-- rev4 -->"); 
$content = substr($content, 0, $pos); 
echo $content;
?></div></div>
  
  <hr class="my-4">
-Пыль – главный источник перегрева/

Содержание: Помимо установки хорошей системы охлаждения, необходимо также следить за чистотой внутреннего пространства системного блока компьютера. При засорении пылью эффективность теплоотводных радиаторов снижается минимум вдвое, а вентилятор, забитый пылью, не в состоянии обеспечивать достаточную циркуляцию воздуха внутри корпуса.Чистка в которую также должны входить: чистка вентиляторов, радиаторов, блока питания и контактных поверхностей компонентов (видеокарты, оперативной памяти и т.д.). Все запчасти вы можете приобрести  https://www.partsdirect.ru/ 
  
  <hr class="my-4">

  <div class="row">
    <div class="col-sm-3  ">
      <div align="center"><img  class="  corners3" src="themes/<?=$setts['default_theme'];?>/duster1.png">
      </div>
      <h4> Dusting Чистка </h4>    
      <p> Поэтому нужно  от пыли вовремя проводить плановую чистку компьютера ,радиаторов, блока питания и контактных поверхностей..</p>
      <p>Replacement HEATSINK.</p> 
    </div>
    <div class="col-sm-3  ">
      <div align="center"><img   class="img-circle corners3 " src="themes/<?=$setts['default_theme'];?>/kpt8.png">
      </div>
      <h4> Замена термопасты  </h4>    
      <p>Здесь вы можете найти как самому заменить термопасту на своем компьютере и ссылки на продавцов термопасты...</p>
      <p>Thermal paste replacement. Термопаста КПТ-8</p>
    </div>
    <div class="col-sm-3">
      <div align="center"><img   class="corners3" src="themes/<?=$setts['default_theme'];?>/cooler.png">
      </div>
      <h4>Ремонт кулера </h4>          
      <p>Трудоемкий процесс но очень нужный чтобы не потерять весь блок процессорный. Сыылки на паблик...</p>
      <p>Replacement cooler.</p>
    </div>
	 <div class="col-sm-3">
	   <div align="center"><img   class="img-circle corners3" src="themes/<?=$setts['default_theme'];?>/heatsink.png">
       </div>
	   <h4> Смена HEATSINK </h4>          
      <p>Сложный ремонт,  но очень реально помогающий фактор при замене хетсинка  , отводит тепло просто огромными областями. Сыылки на паблик...</p>
      <p>Replacement HEATSINK.</p>
    </div>
  </div>
 

  
  
<hr class="my-4">
























 


<h1 class="display-4">Repairs</h1>
  <p class="lead">Модульный ремонт плат, апгрейд процессора и видеокарт.</p>
 
  
  
  
  
  
  
Содержание:  По сравнению с компонентным ремонтом, модульный имеет   недостаток, его цена будет довольно высока Но самому его сделать проще. Как и апгрейд<br />
Аппаратная модернизация подразумевает замену или добавление комплектующих. Например, замена жёсткого диска на твердотельный накопитель для получения более высокой скорости обмена данными. Как самому поменять видеокарту или сделать апгрейд . см ссылки 
<hr class="my-4">
  <div class="row justify-content ">
    <div class="col-sm-6"> <img   class="img-fluid" src="themes/<?=$setts['default_theme'];?>/ww12.png"></div>
    <div class="col-sm-6"> <a class="list-group-item  list-group  bg-dark text-white" href="wanted_ads.php"><i class="icon-tag"></i>  &nbsp; Как самому делать апгрейд  ?   <?=$current_date;?> </a>  <?
$content = file_get_contents("http://nbw.ru/Okhlazhdenie,category,500,parent_id,reverse_auctions");
$pos = strpos($content, "<!-- rev3 -->");
$content = substr($content, $pos); 
$pos = strpos($content, "<!-- rev4 -->"); 
$content = substr($content, 0, $pos); 
echo $content;
?></div></div>













<hr class="my-4">

  <div class="row">
    <div class="col-sm-3">
      <div align="center"><img  class="corners3" src="themes/<?=$setts['default_theme'];?>/ddr3.png">
      </div>
      <h4>Апгрейд </h4>    
      <p>Комп или  ноутбук начинает работать заметно хуже, чем в момент покупки. Долгая загрузка.</p>
      <p>Надо увеличить память. Сменить HDD на SSD <a href="http://localhost/apgrejjd-kompyuetra,category,481,parent_id,reverse_auctions">Апгрейд. см тут</a></p> 
    </div>
    <div class="col-sm-3">
      <div align="center"><img   class="corners3" src="themes/<?=$setts['default_theme'];?>/modul.png">
      </div>
      <h4>Модульный ремонт  </h4>    
      <p> модульный ремонт проводится в случае, если неисправность конкретного блока очевидна. В некоторых сервисных центрах предлагается заменить модуль либо на оригинальную запчасть, </p>
      <p>либо на китайский аналог</p>
    </div>
    <div class="col-sm-3">
      <div align="center"><img    class="corners3" src="themes/<?=$setts['default_theme'];?>/cpu.png">
      </div>
      <h4>Процессора </h4>          
      <p>После замены центрального компонента ваш ноутбук станет намного быстрее. Однако  у каждого устройства есть требоваия. Соответственно можно установить не любой процессор.</p>
      <p><a href="reverse_auctions.php">Replacement CPU</a> .</p>
    </div>
	 <div class="col-sm-3">
	   <div align="center"><img    class="corners3" src="themes/<?=$setts['default_theme'];?>/video.png">
       </div>
	   <h4> Видеокарта </h4>          
       <p>Съемные видеокарты устанавливаются в мобильный модуль на шине PCI Express под названием MXM   и делятся на несколько типов:   ...</p>
      <p><a href="<?=process_link('site_fees');?>">Приобрести видеокарты можно здесь... </a></p>
    </div>
	
	
  </div>



 
				
	  <hr class="my-8">			
				
				
				
				
 

  <h1 class="display-4">  PERIPHERALS!</h1>
  <p class="lead">Мультимедиа — аудио, видео конекторы USB RGB RJ-45 DVI </p>
 
  <hr class="my-4"> <div class="row">
    <div class="col-sm-6"><img  class="img-fluid" src="themes/<?=$setts['default_theme'];?>/usb.png"></div>
     <div class="col-sm-6"> <a class="list-group-item  list-group  bg-dark text-white" href="wanted_ads.php"><i class="icon-tag"></i>  &nbsp; USB RGB RJ-45 DVI  ?   <?=$current_date;?> </a>  <?
$content = file_get_contents("http://nbw.ru/USB-i-raznye-vkhody-vykhody,category,516,parent_id,reverse_auctions");
$pos = strpos($content, "<!-- rev3 -->");
$content = substr($content, $pos); 
$pos = strpos($content, "<!-- rev4 -->"); 
$content = substr($content, 0, $pos); 
echo $content;
?> </div></div>
  <hr class="my-4">


Содержание:

    Mini-jack (3,5 мм)
    Ethernet (RJ-45)
    HDMI
    DisplayPort / Mini DisplayPort
    DVI
    MicroSD
    Адаптер SD
    USB / USB Type-A
    USB Type-B
    USB Type-C
    USB 2.0
    USB 3.0
    USB 3.1 Gen 1
    USB 3.1 Gen 2
    Micro USB
    Mini USB
    Thunderbolt 3
    VGA


<div class="row">
    <div class="col-sm-3">
      <div align="center"><img   class="corners3" src="themes/<?=$setts['default_theme'];?>/MiniJack.png">
      </div>
      <h4> Audio Video jack </h4>    
      <p> (Video) Headphone Jack & Hold Switch Replacement  .Replacement Headphone Jack..</p>
      <p>resolve the problem</p> 
  </div>
    <div class="col-sm-3">
      <div align="center"><img    class="corners3" src="themes/<?=$setts['default_theme'];?>/kpt8.png">
      </div>
      <h4> USB MicroUSB  </h4>    
      <p>Micro-USB Port Replacement: This guide will provide steps that show how to desoldered the Micro-USB port from the motherboard..</p>
      <p>resolve the problem:</p>
  </div>
    <div class="col-sm-3"> <div align="center"><img     class="corners3" src="themes/<?=$setts['default_theme'];?>/dcjack.png">  </div>
     <h4>Коннектор питания connect DC</h4>          
      <p>Трудоемкий процесс замена конектора питания ...</p>
      <p>resolve the problem</p>
    </div>
	 <div  class="col-sm-3"> <div align="center"><img   class="corners3" src="themes/<?=$setts['default_theme'];?>/heatsink.png">  </div>
     <h4>Неисправность блоки питания </h4>          
      <p> Неисправность блока питания ноутбука – это нерядовая проблема. ... Допустим, если причина неисправности определяется визуально...</p>
      <p>resolve the problem.</p>
    </div>
	
	
</div>
 
 
 <hr class="my-4">

<br /> </div>
<script type="text/javascript">

var countries=new ddajaxtabs("countrytabs", "countrydivcontainer")
countries.setpersist(true)
countries.setselectedClassTarget("link") //"link" or "linkparent"
countries.init()

</script>

 	<? } ?>
 
 <hr class="my-4">